#include "minimax.h"
#include "heuristics.h"
#include <algorithm>
#include <random>
#include <iostream>

// Global empty move for default parameter
Move g_empty_move = {"", {}, {}, {}, ""};

static constexpr bool ENABLE_MOVE_ORDERING = true;
static constexpr int MIN_DEPTH_FOR_ORDERING = 2;

// Global counters for pruning statistics
static int nodes_visited = 0;
static int nodes_pruned = 0;

// Helper function to format a move as a readable string
std::string format_move(const Move& move) {
    std::string result;
    if (move.action == "move") {
        result = "move from (" + std::to_string(move.from[0]) + "," + std::to_string(move.from[1]) + 
                 ") to (" + std::to_string(move.to[0]) + "," + std::to_string(move.to[1]) + ")";
    } else if (move.action == "flip") {
        result = "flip at (" + std::to_string(move.from[0]) + "," + std::to_string(move.from[1]) + ")";
    } else if (move.action == "rotate") {
        result = "rotate at (" + std::to_string(move.from[0]) + "," + std::to_string(move.from[1]) + ")";
    } else if (move.action == "push") {
        result = "push from (" + std::to_string(move.from[0]) + "," + std::to_string(move.from[1]) + 
                 ") to (" + std::to_string(move.to[0]) + "," + std::to_string(move.to[1]) + 
                 ") pushing to (" + std::to_string(move.pushed_to[0]) + "," + std::to_string(move.pushed_to[1]) + ")";
    } else {
        result = move.action;
    }
    return result;
}

// Helper function to print the principal variation (expected sequence of moves)
void print_principal_variation(const std::vector<Move>& pv, const std::string& starting_player) {
    // Function disabled to reduce output
}


// Structure to hold ordered moves and their pre-computed heuristics
struct OrderedMovesWithHeuristics {
    std::vector<Move> moves;
    std::vector<Heuristics::HeuristicsInfo> heuristics;
};

// Order moves by heuristic evaluation to improve alpha-beta pruning efficiency
// Returns both the sorted moves AND their heuristics to avoid recomputation
OrderedMovesWithHeuristics order_moves_by_heuristic(GameState& state, const std::vector<Move>& moves,
                                           const std::string& original_player, bool maximizing_player,
                                           Heuristics::HeuristicsInfo* parent_heuristics) {
    struct MoveWithHeuristic {
        double value;
        Move move;
        Heuristics::HeuristicsInfo heuristics;
    };

    std::vector<MoveWithHeuristic> move_evaluations;
    move_evaluations.reserve(moves.size());

    for (const Move& move : moves) {
        GameState::UndoInfo undo = state.make_move(move);
        // Use incremental heuristics (same pattern as in minimax_alpha_beta line 156)
        // Need to cast away const for the move pointer parameter
        Move* move_ptr = const_cast<Move*>(&move);
        Heuristics::HeuristicsInfo heuristics = Heuristics::evaluate_position(state, original_player, true, parent_heuristics, move_ptr);
        state.undo_move(move, undo);
        move_evaluations.push_back({heuristics.total_score, move, heuristics});
    }

    // Sort: descending for max (best first), ascending for min (worst for opponent first)
    std::sort(move_evaluations.begin(), move_evaluations.end(),
              [maximizing_player](const MoveWithHeuristic& a, const MoveWithHeuristic& b) {
                  return maximizing_player ? (a.value > b.value) : (a.value < b.value);
              });

    OrderedMovesWithHeuristics result;
    result.moves.reserve(move_evaluations.size());
    result.heuristics.reserve(move_evaluations.size());
    for (const MoveWithHeuristic& eval : move_evaluations) {
        result.moves.push_back(eval.move);
        result.heuristics.push_back(eval.heuristics);
    }
    return result;
}

// Minimax with alpha-beta pruning - uses make_move/undo_move for efficiency
// NOW WITH TRANSPOSITION TABLE SUPPORT
MinimaxResult minimax_alpha_beta(GameState& state, int depth, double alpha, double beta,
                                 bool maximizing_player, const std::string& original_player,
                                 TranspositionTable* tt, bool allow_tt_cutoff,
                                 std::vector<Move>& move_to_ignore,
                                 Heuristics::HeuristicsInfo* parent_heuristics,
                                 std::chrono::high_resolution_clock::time_point* start_time,
                                 double timeout_seconds) {
    // Increment nodes visited counter
    nodes_visited++;
    
    // Check timeout
    if (start_time != nullptr && timeout_seconds > 0.0) {
        auto current_time = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> elapsed = current_time - *start_time;
        if (elapsed.count() >= timeout_seconds) {
            // Timeout exceeded - return current evaluation immediately
            double eval = Heuristics::evaluate_position(state, original_player, false).total_score;
            return MinimaxResult(eval, {"move", {0,0}, {0,0}, {}, ""}, {});
        }
    }
    
    // ===== TRANSPOSITION TABLE PROBE =====
    // Check if we've already evaluated this position at sufficient depth
    // BUT: Don't return cached result at root level (we need the actual best move!)
    if (tt != nullptr && allow_tt_cutoff) {
        double cached_value;
        if (tt->probe(state, depth, alpha, beta, cached_value)) {
            // Cache hit! Return cached value without further search
            // NOTE: We don't have the move, but that's OK for non-root nodes
            return MinimaxResult(cached_value, {"move", {0,0}, {0,0}, {}, ""}, {});
        }
    }
    
    // Base case: terminal state or depth limit reached
    if (depth == 0 || state.is_terminal()) {
        double eval = Heuristics::evaluate_position(state, original_player, false).total_score;
        
        // Store leaf evaluation in TT (exact value)
        if (tt != nullptr) {
            tt->store(state, depth, eval, EntryType::EXACT);
        }
        
        return MinimaxResult(eval, {"move", {0,0}, {0,0}, {}, ""}, {});
    }

    std::vector<Move> legal_moves = state.get_legal_moves();
    for (const Move& move : move_to_ignore) {
        if (std::find(legal_moves.begin(), legal_moves.end(), move) != legal_moves.end()) {
            legal_moves.erase(std::remove(legal_moves.begin(), legal_moves.end(), move), legal_moves.end());
        }
    }
    if (legal_moves.empty()) {
        double eval = Heuristics::evaluate_position(state, original_player, false).total_score;
        
        // Store terminal position evaluation
        if (tt != nullptr) {
            tt->store(state, depth, eval, EntryType::EXACT);
        }
        
        return MinimaxResult(eval, {"move", {0,0}, {0,0}, {}, ""}, {});
    }

    // Order moves for better pruning, or shuffle if depth is shallow
    // When ordering, also cache the heuristics to avoid recomputation
    std::vector<Move> moves_to_explore;
    std::vector<Heuristics::HeuristicsInfo> cached_heuristics;
    bool use_cached_heuristics = false;

    if (depth >= MIN_DEPTH_FOR_ORDERING && ENABLE_MOVE_ORDERING) {
        OrderedMovesWithHeuristics ordered = order_moves_by_heuristic(state, legal_moves, original_player, maximizing_player, parent_heuristics);
        moves_to_explore = std::move(ordered.moves);
        cached_heuristics = std::move(ordered.heuristics);
        use_cached_heuristics = true;
    } else {
        moves_to_explore = legal_moves;
        std::shuffle(moves_to_explore.begin(), moves_to_explore.end(), std::mt19937{std::random_device{}()});
    }

    Move best_move = moves_to_explore.back();
    double best_value = maximizing_player ? -std::numeric_limits<double>::infinity()
                                          : std::numeric_limits<double>::infinity();
    double original_alpha = alpha;  // Save for TT entry type determination
    std::vector<Move> best_pv;  // Track the principal variation

    for (size_t i = 0; i < moves_to_explore.size(); ++i) {
        Move move = moves_to_explore[i];
        GameState::UndoInfo undo = state.make_move(move);

        // CRITICAL OPTIMIZATION: Reuse cached heuristics from move ordering instead of recomputing!
        Heuristics::HeuristicsInfo my_heuristics;
        if (use_cached_heuristics) {
            // Use the pre-computed heuristics from ordering - no recomputation needed!
            my_heuristics = cached_heuristics[i];
        } else {
            // Compute fresh (only when we didn't do move ordering)
            my_heuristics = Heuristics::evaluate_position(state, original_player, true, parent_heuristics, &move);
        }

        // Principal Variation Search (PVS):
        // First (best-ordered) move gets full window; subsequent moves get a null-window search,
        // and only on a potential improvement do we re-search with the full window.
        MinimaxResult result = (i == 0)
            ? minimax_alpha_beta(state, depth - 1, alpha, beta,
                                  !maximizing_player, original_player, tt, true, move_to_ignore, &my_heuristics, start_time, timeout_seconds)
            : [&]() {
                  double pvs_alpha = maximizing_player ? alpha : (beta - 1);
                  double pvs_beta  = maximizing_player ? (alpha + 1) : beta;
                  MinimaxResult narrow = minimax_alpha_beta(state, depth - 1, pvs_alpha, pvs_beta,
                                                           !maximizing_player, original_player, tt, true, move_to_ignore, &my_heuristics, start_time, timeout_seconds);
                  bool needs_full_window = maximizing_player
                                           ? (narrow.value > alpha && narrow.value < beta)
                                           : (narrow.value < beta && narrow.value > alpha);
                  if (needs_full_window) {
                      return minimax_alpha_beta(state, depth - 1, alpha, beta,
                                                !maximizing_player, original_player, tt, true, move_to_ignore, &my_heuristics, start_time, timeout_seconds);
                  }
                  return narrow;
              }();
        state.undo_move(move, undo);

        if (maximizing_player) {
            if (result.value > best_value) {
                best_value = result.value;
                best_move = move;
                // Build PV: current move + rest of variation
                best_pv.clear();
                best_pv.push_back(move);
                best_pv.insert(best_pv.end(), result.principal_variation.begin(), result.principal_variation.end());
            }
            alpha = std::max(alpha, result.value);
        } else {
            if (result.value < best_value) {
                best_value = result.value;
                best_move = move;
                // Build PV: current move + rest of variation
                best_pv.clear();
                best_pv.push_back(move);
                best_pv.insert(best_pv.end(), result.principal_variation.begin(), result.principal_variation.end());
            }
            beta = std::min(beta, result.value);
        }

        if (beta <= alpha) {
            // Alpha-beta cutoff: prune remaining siblings
            int remaining_moves = moves_to_explore.size() - i - 1;
            nodes_pruned += remaining_moves;
            break; // Alpha-beta pruning
        }
    }

    // ===== TRANSPOSITION TABLE STORE =====
    // Store this position's evaluation for future use
    if (tt != nullptr) {
        EntryType entry_type;
        
        if (best_value <= original_alpha) {
            // Failed low - we didn't improve alpha
            // This is an upper bound (actual value <= best_value)
            entry_type = EntryType::UPPER_BOUND;
        } else if (best_value >= beta) {
            // Failed high - we caused a beta cutoff
            // This is a lower bound (actual value >= best_value)
            entry_type = EntryType::LOWER_BOUND;
        } else {
            // Value is within [alpha, beta] window
            // This is an exact value
            entry_type = EntryType::EXACT;
        }
        
        tt->store(state, depth, best_value, entry_type);
    }

    return MinimaxResult(best_value, best_move, best_pv);
}

// Repetition detection utilities using board state hashing
// Similar to stalemate detection in gameEngine.py
bool would_cause_stalemate(GameState& initial_state, const Move& move,
                          const std::deque<uint64_t>& recent_board_hashes,
                          TranspositionTable* tt) {
    // Check if the move would result in a board state that matches any of the last 6 recorded states
    if (tt == nullptr || recent_board_hashes.empty()) {
        return false;
    }

    // Simulate the move using make_move/undo_move to get the resulting board hash
    GameState::UndoInfo undo = initial_state.make_move(move);

    // Use incremental hash if available, otherwise compute from scratch
    uint64_t new_hash;
    if (initial_state.hash_initialized && initial_state.tt_for_hashing == tt) {
        new_hash = initial_state.zobrist_hash;
    } else {
        new_hash = tt->compute_hash(initial_state);
    }

    initial_state.undo_move(move, undo);

    // Check if new_hash matches any of the last 6 recorded states
    for (size_t i = 0; i < recent_board_hashes.size(); ++i) {
        if (new_hash == recent_board_hashes[i]) {
            return true;
        }
    }

    return false;
}

void record_board_state(const GameState& state, std::deque<uint64_t>& recent_board_hashes,
                       TranspositionTable* tt) {
    if (tt == nullptr) return;
    
    // Use incremental hash if available, otherwise compute from scratch
    uint64_t current_hash;
    if (state.hash_initialized && state.tt_for_hashing == tt) {
        current_hash = state.zobrist_hash;
    } else {
        current_hash = tt->compute_hash(state);
    }
    
    recent_board_hashes.push_back(current_hash);
    
    // Keep only last 6 states (enough to check pattern across 4-move cycles)
    // We check states at -4, -2, and current (0), so need 5 total
    // But keep 6 for safety margin
    if (recent_board_hashes.size() > 6) {
        recent_board_hashes.pop_front();
    }
}

Move run_minimax_with_repetition_check(const GameState& initial_state, int max_depth,
                                       const std::string& side, std::deque<uint64_t>& recent_board_hashes,
                                       TranspositionTable* tt,
                                       std::chrono::high_resolution_clock::time_point* start_time,
                                       double timeout_seconds) {
    
    std::vector<Move> legal_moves = initial_state.get_legal_moves();
    int num_legal_moves = legal_moves.size();
    
    if (legal_moves.empty()) {
        return {"move", {0,0}, {0,0}, {}, ""};
    }

    // Reset pruning statistics
    nodes_visited = 0;
    nodes_pruned = 0;
    
    GameState working_state = initial_state.copy();
    
    // Initialize incremental hash if TT is available
    if (tt != nullptr) {
        working_state.initialize_hash(tt);
    }
    
    // Move move_to_ignore = {"", {}, {}, {}, ""};
    std::vector <Move> move_to_ignore;
    
    // Create internal start time if not provided
    auto internal_start = std::chrono::high_resolution_clock::now();
    auto* time_ptr = (start_time != nullptr) ? start_time : &internal_start;
    
    // Use standard alpha-beta minimax with the specified depth and TT
    // IMPORTANT: allow_tt_cutoff=false at root to ensure we get actual best move
    MinimaxResult result = minimax_alpha_beta(working_state, max_depth,
                                              -std::numeric_limits<double>::infinity(),
                                              std::numeric_limits<double>::infinity(),
                                              true,  // maximizing player
                                              initial_state.current_player,
                                              tt,    // Pass TT to minimax
                                              false,
                                              move_to_ignore,
                                              nullptr, // DON'T allow TT cutoff at root!
                                              time_ptr,
                                              timeout_seconds);
    
    // Check if we timed out and should retry with depth 3
    auto end_time = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> duration = end_time - *time_ptr;
    
    if (timeout_seconds > 0.0 && duration.count() >= timeout_seconds-0.5 && max_depth > 3) {
        std::cout << "Depth " << max_depth << " search exceeded " << timeout_seconds 
                  << "s timeout (" << duration.count() << "s). Falling back to depth 3..." << std::endl;
        
        // Reset for retry
        nodes_visited = 0;
        nodes_pruned = 0;
        move_to_ignore.clear();
        
        auto retry_start = std::chrono::high_resolution_clock::now();
        result = minimax_alpha_beta(working_state, 3,
                                   -std::numeric_limits<double>::infinity(),
                                   std::numeric_limits<double>::infinity(),
                                   true,
                                   initial_state.current_player,
                                   tt,
                                   false,
                                   move_to_ignore,
                                   nullptr,
                                   nullptr,  // No timeout for fallback
                                   0.0);
        auto retry_end = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> retry_duration = retry_end - retry_start;
        std::cout << "Depth 3 fallback completed in " << retry_duration.count() << " seconds." << std::endl;
    } else if (timeout_seconds > 0.0 || max_depth >= 3) {
        std::cout << "Search completed in " << duration.count() << " seconds (depth " << max_depth << ")." << std::endl;
    }
    Move selected = result.best_move;

    // Check for stalemate (alternating repetition pattern) and find alternative if needed
    while (would_cause_stalemate(working_state, selected, recent_board_hashes, tt) && result.value != -1e9) {
        
        move_to_ignore.push_back(selected);
        // Rerun minimax ignoring the stalemate-causing move
        
        // Reset pruning statistics for the re-run
        nodes_visited = 0;
        nodes_pruned = 0;
        
        result = minimax_alpha_beta(working_state, max_depth,
                                    -std::numeric_limits<double>::infinity(),
                                    std::numeric_limits<double>::infinity(),
                                    true,  // maximizing player
                                    initial_state.current_player,
                                    tt,    // Pass TT to minimax
                                    false,
                                    move_to_ignore,
                                    nullptr, // DON'T allow TT cutoff at root!
                                    start_time,
                                    timeout_seconds);
        selected = result.best_move;
    }

    // Record the resulting board state after making this move
    GameState after_state = initial_state.copy();
    after_state.apply_move(selected);
    record_board_state(after_state, recent_board_hashes, tt);
    
    return selected;
}